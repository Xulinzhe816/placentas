import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.nn import init


class ECAAttention(nn.Module):     # 定义 ECA注意力， 用于上采样后的特征融合

    def __init__(self, kernel_size=3):
        super().__init__()
        self.gap = nn.AdaptiveAvgPool2d(1)
        self.conv = nn.Conv1d(1, 1, kernel_size=kernel_size, padding=(kernel_size-1)//2)
        self.sigmoid = nn.Sigmoid()

    def init_weights(self):
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    init.constant_(m.bias, 0)
            elif isinstance(m, nn.BatchNorm2d):
                init.constant_(m.weight, 1)
                init.constant_(m.bias, 0)
            elif isinstance(m, nn.Linear):
                init.normal_(m.weight, std=0.001)
                if m.bias is not None:
                    init.constant_(m.bias, 0)

    def forward(self, x):
        y = self.gap(x)  # bs, c, 1, 1
        y = y.squeeze(-1).permute(0,2,1)  # bs, 1, c
        y = self.conv(y)  # bs, 1, c
        y = self.sigmoid(y)  # bs, 1, c
        y = y.permute(0, 2, 1).unsqueeze(-1)  # bs, c, 1, 1
        return x*y.expand_as(x)

class Res2Bottleneck(nn.Module):
    expansion = 4
    def __init__(self, inplanes, planes, stride=1, scales=4, groups=1,  norm_layer=True):
        super(Res2Bottleneck, self).__init__()

        if planes % scales != 0:
            raise ValueError('Planes must be divisible by scales')
        if norm_layer:
            norm_layer = nn.BatchNorm2d

        self.scales = scales
        self.stride = stride
        self.conv1 = nn.Conv2d(inplanes, planes, kernel_size=1, stride=stride)
        self.bn1 = norm_layer(planes)
        self.conv2 = nn.ModuleList([nn.Conv2d(planes // scales, planes // scales,
                                              kernel_size=3, stride=1, padding=1, groups=groups) for _ in range(scales-1)])
        self.bn2 = nn.ModuleList([norm_layer(planes // scales) for _ in range(scales-1)])
        self.conv3 = nn.Conv2d(planes, planes, kernel_size=1, stride=1)
        self.bn3 = norm_layer(planes)
        self.relu = nn.ReLU(inplace=True)

        self.eca = ECAAttention()

        self.shortcut = nn.Sequential(  # 定义残差边
            nn.Conv2d(inplanes, planes, kernel_size=1, bias=False),
            nn.BatchNorm2d(planes)
        )

    def forward(self, x):
        identity = x

        # 1*1的卷积层
        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        # 4个(3x3)的残差分层架构
        xs = torch.chunk(out, self.scales, 1) # 将x分割成4块
        ys = []
        for s in range(self.scales):
            if s == 0:
                ys.append(xs[s])
            elif s == 1:
                ys.append(self.relu(self.bn2[s-1](self.conv2[s-1](xs[s]))))
            else:
                ys.append(self.relu(self.bn2[s-1](self.conv2[s-1](xs[s] + ys[-1]))))
        out = torch.cat(ys, 1)

        # 1*1的卷积层
        out = self.conv3(out)
        out = self.bn3(out)

        # 1*1后接ECA
        out = self.eca(out)

        # 残差层
        out += self.shortcut(identity)
        out = self.relu(out)


        return out

class doubleConv(nn.Module):   # 最上层的两个卷积块
    def __init__(self, in_planes, planes):
        super(doubleConv, self).__init__()
        self.conv1 = nn.Conv2d(in_planes, planes, kernel_size=3, padding=1, bias=False)  # 定义两个卷积，bn
        self.conv2 = nn.Conv2d(planes, planes, kernel_size=3, padding=1, bias=False)
        self.bn = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(True)

    def forward(self, x):
        out = self.relu(self.bn(self.conv1(x)))
        out = self.relu(self.bn(self.conv2(out)))             # 特征图经过两次卷积
        return out



class AttunetUp(nn.Module):   # 加入注意力的特征融合
    def __init__(self, in_size, out_size):
        super(AttunetUp, self).__init__()
        self.conv1 = nn.Conv2d(in_size, out_size, kernel_size=3, padding=1)
        self.conv2 = nn.Conv2d(out_size, out_size, kernel_size=3, padding=1)
        self.bn = nn.BatchNorm2d(out_size)
        self.relu = nn.ReLU(True)
        self.up = nn.UpsamplingBilinear2d(scale_factor=2)
        self.eca = ECAAttention()


    def forward(self, inputs1, inputs2):

        outputs = torch.cat([inputs1, self.up(inputs2)], 1)    # 上采用与特征融合
        outputs = self.eca(self.conv1(outputs))                # 卷积加ECA注意力
        outputs = self.relu(self.bn(self.conv2(outputs)))

        return outputs


class Unet(nn.Module):   # 定义整体UNet网络
    def __init__(self, num_classes=21, in_channels=3, pretrained=False, record=False):
        super(Unet, self).__init__()
        self.layer1 = doubleConv(in_channels, 64)   # Unet 编码器第一层
        self.layer2 = Res2Bottleneck(64, 128)   # Unet 编码器第二层
        self.layer3 = Res2Bottleneck(128, 256)   # Unet 编码器第三层
        self.layer4 = Res2Bottleneck(256, 512)   # Unet 编码器第四层
        self.layer5 = Res2Bottleneck(512, 512)   # Unet 编码器第五层
        self.downsample = nn.MaxPool2d(kernel_size=2, stride=2)  # 下采样层

        in_filters = [192, 384, 768, 1024]
        out_filters = [64, 128, 256, 512]

        self.up_concat4 = AttunetUp(in_filters[3], out_filters[3])  # 解码器第四层
        self.up_concat3 = AttunetUp(in_filters[2], out_filters[2])  # 解码器第三层
        self.up_concat2 = AttunetUp(in_filters[1], out_filters[1])  # 解码器第二层
        self.up_concat1 = AttunetUp(in_filters[0], out_filters[0])  # 解码器第一层

        self.final = nn.Conv2d(out_filters[0], num_classes, 1)

    def forward(self, inputs):
        layer1 = self.layer1(inputs)
        down1 = self.downsample(layer1)
        layer2 = self.layer2(down1)
        down2 = self.downsample(layer2)
        layer3 = self.layer3(down2)
        down3 = self.downsample(layer3)
        layer4 = self.layer4(down3)
        down4 = self.downsample(layer4)
        layer5 = self.layer5(down4)

        up4 = self.up_concat4(layer4, layer5)
        up3 = self.up_concat3(layer3, up4)
        up2 = self.up_concat2(layer2, up3)
        up1 = self.up_concat1(layer1, up2)

        final = self.final(up1)
        return final


    def _initialize_weights(self, *stages):
        for modules in stages:
            for module in modules.modules():
                if isinstance(module, nn.Conv2d):
                    nn.init.kaiming_normal_(module.weight)
                    if module.bias is not None:
                        module.bias.data.zero_()
                elif isinstance(module, nn.BatchNorm2d):
                    module.weight.data.fill_(1)
                    module.bias.data.zero_()



from torchsummary import summary
model = Unet(2, 3).cuda()
summary(model, input_size=(3, 512, 512), batch_size=2)
